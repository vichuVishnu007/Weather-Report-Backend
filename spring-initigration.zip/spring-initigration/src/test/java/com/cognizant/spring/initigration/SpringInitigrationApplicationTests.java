package com.cognizant.spring.initigration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringInitigrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
