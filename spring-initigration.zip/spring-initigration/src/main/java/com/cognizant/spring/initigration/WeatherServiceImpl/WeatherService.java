package com.cognizant.spring.initigration.WeatherServiceImpl;

import com.cognizant.spring.initigration.Model.Request.UserTransaction;
import com.cognizant.spring.initigration.Model.Response.WeatherDetails;
import reactor.core.publisher.Mono;


public interface WeatherService {
    public Mono<WeatherDetails> getWeatherDetails(String location);
    public Mono<UserTransaction> getTransactions(String id);
}
