package com.cognizant.spring.initigration.WeatherServiceImpl;


import com.cognizant.spring.initigration.Model.Response.WeatherDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.UUID;

@Component
public class OpenWeatherApiCallService {

    @Autowired
    RestTemplate restTemplate;

    @Value("${weather.api.securityKey}")
    private String secretKey;

    public Mono<WeatherDetails> getWeatherDetails(String location){
        String uriBuilder = "https://api.openweathermap.org/data/2.5/weather?q=" +
                location +
                "&appid=" +
                secretKey;

        URI uri = URI.create(uriBuilder);
        try {
            WeatherDetails weatherDetails =  restTemplate.exchange(uri, HttpMethod.POST,new HttpEntity<>(new HttpHeaders()),WeatherDetails.class).getBody();
            if (weatherDetails != null) {
                weatherDetails.setCorrelationID(String.valueOf(UUID.randomUUID()));
            }
            return Mono.just(weatherDetails!=null?weatherDetails:new WeatherDetails());
        }
        catch (RestClientException e){
            e.printStackTrace();
        }
        return Mono.just(new WeatherDetails());
    }
}
