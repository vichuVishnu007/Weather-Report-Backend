package com.cognizant.spring.initigration.WeatherServiceImpl;


import com.cognizant.spring.initigration.Model.Request.UserTransaction;
import com.cognizant.spring.initigration.Model.Response.WeatherDetails;
import com.cognizant.spring.initigration.Respository.TransactionRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.sql.Timestamp;
import java.util.UUID;

@Service
public class WeatherServiceImpl implements WeatherService{

    Logger logger = LoggerFactory.getLogger(WeatherServiceImpl.class);

    @Autowired
    OpenWeatherApiCallService openWeatherApiCallService;

    @Autowired
    TransactionRepository transactionRepository;


    public Mono<Boolean> validateRequest(String location){
        return StringUtils.hasText(location) ? Mono.just(Boolean.TRUE) : Mono.just(Boolean.FALSE);
    }


    public Mono<String> validateResponse(){

        return null;
    }

    @Override
    public Mono<WeatherDetails> getWeatherDetails(String location) {
        logger.info(" Entered getWeatherDetails in Service with request param {}",location);
        Mono<Boolean> validateRequestStatus = validateRequest(location);
        return validateRequestStatus.flatMap(status -> {
            logger.info(" Request Validation status {}",status);
            if(status.equals(Boolean.TRUE)){
              Mono<WeatherDetails> weatherDetailsMono =  openWeatherApiCallService.getWeatherDetails(location);
              Mono<UserTransaction> saveTransaction = saveTransaction(weatherDetailsMono);
              Mono<Tuple2<WeatherDetails, UserTransaction>> tuple2Mono = Mono.zip(weatherDetailsMono,saveTransaction);
              return tuple2Mono.flatMap(transaction -> {
                  transactionRepository.save(transaction.getT2());
                  return Mono.just(transaction.getT1());
              });
            }

            return Mono.just(new WeatherDetails());
        });
    }

    @Override
    public Mono<UserTransaction> getTransactions(String id) {
        return transactionRepository.findById(id);
    }

    public Mono<UserTransaction> saveTransaction(Mono<WeatherDetails> weatherDetails){
        ObjectMapper objectMapper = new ObjectMapper();
        return weatherDetails.flatMap(weatherDetail -> {
            try {
                String transactionDetails = objectMapper.writeValueAsString(weatherDetail);
                UserTransaction transaction = new UserTransaction();
                transaction.setCorrelationID(String.valueOf(UUID.randomUUID()));
                transaction.setPayload(transactionDetails);
                Timestamp timestamp = new Timestamp(System.currentTimeMillis());
                transaction.setDatetime(String.valueOf(timestamp));
                System.out.print(transaction);
                return Mono.just(transaction);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        });
    }
}
