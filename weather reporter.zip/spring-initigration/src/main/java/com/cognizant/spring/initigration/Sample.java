package com.cognizant.spring.initigration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Sample {

    public static void main(String[] args) {

        String text = "aabbAAccX";
        int[] number = new int[]{1,2,3,4,5};
        int counter = 0;

        List<Character> distinctCharacter = new ArrayList<>(); //abAcX
        Map<Character,Integer> count = new HashMap<>();
        for(char letter : text.toCharArray()){
            if(!distinctCharacter.contains(letter)){
                distinctCharacter.add(letter);
            }
        }
        for (Character character : distinctCharacter) {
            for (int j = 0; j < text.length(); j++) {
                if (text.toCharArray()[j] == character) {
                    counter++;
                }
            }
            count.put(character, counter);
            counter = 0;
        }
        System.out.println(count);
        for (int i= number.length-1; i>-1 ; i--){
            System.out.print(number[i]);
        }
    }
}
