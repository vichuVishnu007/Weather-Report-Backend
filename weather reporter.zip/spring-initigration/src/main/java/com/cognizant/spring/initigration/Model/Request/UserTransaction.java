package com.cognizant.spring.initigration.Model.Request;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Table("user_transaction")
public class UserTransaction {

    @Id
    private String correlationID;

    private String payload;

    private String datetime;

    public UserTransaction() {
    }

    @Override
    public String toString() {
        return "UserTransaction{" +
                "correlationID='" + correlationID + '\'' +
                ", payload='" + payload + '\'' +
                ", datetime='" + datetime + '\'' +
                '}';
    }
}
