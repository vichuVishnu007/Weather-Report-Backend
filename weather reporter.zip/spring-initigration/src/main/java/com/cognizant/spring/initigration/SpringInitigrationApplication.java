package com.cognizant.spring.initigration;


import io.r2dbc.spi.ConnectionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.h2.H2ConsoleAutoConfiguration;
import org.springframework.boot.r2dbc.ConnectionFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import org.springframework.r2dbc.connection.init.ConnectionFactoryInitializer;
import org.springframework.r2dbc.connection.init.ResourceDatabasePopulator;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableR2dbcRepositories
//@EnableWebFlux
@Import(value={H2ConsoleAutoConfiguration.class})
public class SpringInitigrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInitigrationApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(){
		return new RestTemplate();
	}

	@Bean
	public ConnectionFactoryInitializer initializer(ConnectionFactory factory){
		ConnectionFactoryInitializer connectionFactoryInitializer = new ConnectionFactoryInitializer();
		connectionFactoryInitializer.setConnectionFactory(factory);
		connectionFactoryInitializer.setDatabasePopulator(new ResourceDatabasePopulator(new ClassPathResource("schema.sql")));
		return connectionFactoryInitializer;
	}

	@Bean
	public ConnectionFactory connectionFactory(){
		return ConnectionFactoryBuilder.withUrl("r2dbc:h2:mem:///testdb")
				.username("sa")
				.password("cts")
				.build();
	}

	@Bean
	public R2dbcEntityTemplate r2dbcEntityTemplate(ConnectionFactory connectionFactory){
		return new R2dbcEntityTemplate(connectionFactory);
	}
}
