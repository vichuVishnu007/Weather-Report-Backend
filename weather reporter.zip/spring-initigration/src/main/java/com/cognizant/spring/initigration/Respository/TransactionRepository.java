package com.cognizant.spring.initigration.Respository;

import com.cognizant.spring.initigration.Model.Request.UserTransaction;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;


public interface TransactionRepository extends ReactiveCrudRepository<UserTransaction,String> {

    @Query("SELECT u FROM user_transaction AS u  where u.correlationID = :id")
    public Mono<UserTransaction> findByCorrelationID(String id);
}