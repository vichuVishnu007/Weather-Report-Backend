package com.cognizant.spring.initigration.controller;


import com.cognizant.spring.initigration.Model.Request.UserTransaction;
import com.cognizant.spring.initigration.Model.Response.WeatherDetails;
import com.cognizant.spring.initigration.WeatherServiceImpl.WeatherService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;


@RestController
public class WeatherController {

    @Autowired
    WeatherService weather;

    @Value("${spring.application.name}")
    private String applicationName;

    Logger logger = LoggerFactory.getLogger(WeatherController.class);

    @GetMapping("/test")
    public String applicationTest(){
        return "Service "+applicationName+" Up!!!";
    }

    @GetMapping("/getWeatherDetails")
    public Mono<WeatherDetails> getWeatherDetails(@RequestParam String location){
        logger.info(" Entered getWeatherDetails in Controller with request param {}",location);
        return weather.getWeatherDetails(location);
    }

    @GetMapping("/getTransaction")
    public Mono<UserTransaction> getTransactionByID(@RequestParam String coid){
        logger.info("Entered into getTransaction with request param {}",coid);
        return  weather.getTransactions(coid);
    }
}
